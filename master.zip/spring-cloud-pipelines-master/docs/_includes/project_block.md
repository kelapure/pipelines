<div class="project--container">
	<a href="{{include.site_url}}">
		<div class="project--title">{{include.project_title}}</div>
		<p class="project--description">{{include.project_description}}</p>
	</a>
</div>