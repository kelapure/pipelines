#!/bin/bash

set -o errexit

__DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ -f "${__DIR}/pipeline.sh" ]] && source "${__DIR}/pipeline.sh" || \
    echo "No pipeline.sh found"

echo "Running retrieval of group and artifactid to download all dependencies. It might take a while..."
projectGroupId=$( retrieveGroupId )
projectArtifactId=$( retrieveArtifactId )

rm -rf ${OUTPUT_FOLDER}/test.properties
# Find latest prod version
LATEST_PROD_TAG=$( findLatestProdTag )
echo "Last prod tag equals ${LATEST_PROD_TAG}"
if [[ -z "${LATEST_PROD_TAG}" ]]; then
    echo "No prod release took place - skipping this step"
else
    # Downloading latest jar
    LATEST_PROD_VERSION=${LATEST_PROD_TAG#prod/}
    echo "Last prod version equals ${LATEST_PROD_VERSION}"
    downloadJar 'true' ${REPO_WITH_JARS} ${projectGroupId} ${projectArtifactId} ${LATEST_PROD_VERSION}
    logInToCf "${REDOWNLOAD_INFRA}" "${CF_TEST_USERNAME}" "${CF_TEST_PASSWORD}" "${CF_TEST_ORG}" "${CF_TEST_SPACE}" "${CF_TEST_API_URL}"
    UNIQUE_RABBIT_NAME="rabbitmq-${projectArtifactId}"
    if [[ "${REDEPLOY_INFRA}" == "true" ]]; then
        UNIQUE_EUREKA_NAME="eureka-${projectArtifactId}"
    fi
    UNIQUE_MYSQL_NAME="mysql-${projectArtifactId}"
    UNIQUE_STUBRUNNER_NAME="stubrunner-${projectArtifactId}"
    deployAndRestartAppWithNameForSmokeTests ${projectArtifactId} "${projectArtifactId}-${LATEST_PROD_VERSION}" "${UNIQUE_RABBIT_NAME}" "${UNIQUE_EUREKA_NAME}" "${UNIQUE_MYSQL_NAME}"
    propagatePropertiesForTests ${projectArtifactId}
    # Adding latest prod tag
    echo "LATEST_PROD_TAG=${LATEST_PROD_TAG}" >> ${OUTPUT_FOLDER}/test.properties
fi
